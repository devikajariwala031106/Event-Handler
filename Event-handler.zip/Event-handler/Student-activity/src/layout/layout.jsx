export const layout = {
    container: {
        height: "100%",      
        minHeight: "100vh",  
        display: "flex",
        alignItems: "center",  
        justifyContent: "center", 
        background: "#e8f0ff", 
        padding: 20,
    },

    card: {
        width: 720,
        background: "#ffffff",
        padding: 24,
        margin: "0 auto",
        borderRadius: 8,
        boxShadow: "0 6px 18px rgba(20,20,40,0.08)", 
    },

    title: { fontSize: 26, margin: "0 0 12px 0", color: "#0b3d91" },

    form: { display: "flex", gap: 12, marginBottom: 12, alignItems: "center" },
    input: {
        flex: 1,
        padding: "10px 12px",
        borderRadius: 6,
        border: "1px solid #aaa", 
        fontSize: 14,
        background: "#fff",
        color: "#333",
    },

    buttons: { display: "flex", gap: 8 },
    addBtn: {
        padding: "10px 14px",
        borderRadius: 6,
        border: "none",
        cursor: "pointer",
        background: "#0b74ff", 
        color: "#fff",
    },
    clearBtn: {
        padding: "10px 12px",
        borderRadius: 6,
        border: "1px solid #aaa", 
        cursor: "pointer",
        background: "#f0f0f0", 
        color: "#333",
    },

    summary: {
        display: "flex",
        gap: 16,
        padding: "12px 0",
        borderTop: "1px solid #ccc", 
        borderBottom: "1px solid #ccc",
        margin: "12px 0",
    },

    empty: { padding: 24, textAlign: "center", color: "#888" }, 

    cardItem: {
        padding: 12,
        borderRadius: 6,
        border: "1px solid #ddd",
        marginBottom: 12,
        background: "#f5f9ff", 
    },

    cardHeader: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
    },

    headerBtns: { display: "flex", gap: 8, alignItems: "center" },

    smallBtn: {
        padding: "6px 8px",
        borderRadius: 6,
        border: "1px solid #0b74ff",
        background: "#e4f0ff",
        color: "#0b3d91",
        cursor: "pointer",
    },

    deleteBtn: {
        padding: "6px 8px",
        borderRadius: 6,
        border: "none",
        background: "#ff4c4c",
        color: "#fff",
        cursor: "pointer",
    },

    details: {
        marginTop: 8,
        paddingTop: 8,
        borderTop: "1px dashed #b0b0b0",
        fontSize: 13,
        color: "#333",
    },

    actionRow: { display: "flex", gap: 8, marginTop: 8 },
    actionBtn: {
        padding: "6px 8px",
        borderRadius: 6,
        border: "1px solid #0b74ff",
        background: "#e4f0ff",
        color: "#0b3d91",
        cursor: "pointer",
    },
};